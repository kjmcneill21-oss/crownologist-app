// POST /api/send-report — emails the report to the client from your Academy address, photos attached (Resend).
export const config = { maxDuration: 30 };
const validEmail = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e || "");

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ code: "method_not_allowed" });
  if (process.env.APP_ACCESS_CODE && req.headers["x-access-code"] !== process.env.APP_ACCESS_CODE)
    return res.status(401).json({ code: "bad_code" });
  if (!process.env.RESEND_API_KEY || !process.env.REPORT_FROM) return res.status(500).json({ code: "email_not_set_up" });

  const { to, subject, body, photos = [] } = req.body || {};
  if (!validEmail(to) || typeof subject !== "string" || typeof body !== "string" || body.length > 20000)
    return res.status(400).json({ code: "invalid_request" });

  const attachments = (Array.isArray(photos) ? photos.slice(0, 7) : [])
    .filter((p) => typeof p === "string" && p.startsWith("data:image/jpeg;base64,"))
    .map((p, i) => ({ filename: `scalp-point-${i + 1}.jpg`, content: p.split(",")[1] }));

  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: process.env.REPORT_FROM,
        to: [to],
        reply_to: process.env.REPLY_TO || undefined,
        subject: subject.slice(0, 200),
        text: body,
        attachments,
      }),
    });
    if (!r.ok) return res.status(502).json({ code: "email_failed" });
    return res.status(200).json({ ok: true });
  } catch (e) {
    return res.status(502).json({ code: "email_failed" });
  }
}
