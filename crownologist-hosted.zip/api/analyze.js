// POST /api/analyze  — sends the scalp photos and prompt to Claude with YOUR key (kept on the server).
export const config = { maxDuration: 60 };

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ code: "method_not_allowed" });
  if (process.env.APP_ACCESS_CODE && req.headers["x-access-code"] !== process.env.APP_ACCESS_CODE)
    return res.status(401).json({ code: "bad_code" });
  if (!process.env.ANTHROPIC_API_KEY) return res.status(500).json({ code: "server_not_set_up" });

  const { prompt, images = [] } = req.body || {};
  if (typeof prompt !== "string" || !prompt || prompt.length > 200000) return res.status(400).json({ code: "invalid_request" });
  if (!Array.isArray(images) || images.length > 7) return res.status(400).json({ code: "invalid_request" });
  const okTypes = ["image/jpeg", "image/png", "image/webp"];
  for (const im of images) if (!okTypes.includes(im.media_type) || typeof im.data !== "string") return res.status(400).json({ code: "image_rejected" });

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
        max_tokens: 4000,
        messages: [{
          role: "user",
          content: [
            ...images.map((im) => ({ type: "image", source: { type: "base64", media_type: im.media_type, data: im.data } })),
            { type: "text", text: prompt },
          ],
        }],
      }),
    });
    if (r.status === 429) return res.status(429).json({ code: "rate_limited" });
    if (!r.ok) return res.status(502).json({ code: "upstream_error" });
    const data = await r.json();
    const text = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n");
    const start = text.indexOf("{"), end = text.lastIndexOf("}");
    if (start < 0 || end <= start) return res.status(502).json({ code: "invalid_json" });
    let result;
    try { result = JSON.parse(text.slice(start, end + 1)); } catch { return res.status(502).json({ code: "invalid_json" }); }
    return res.status(200).json({ result });
  } catch (e) {
    return res.status(502).json({ code: "upstream_error" });
  }
}
