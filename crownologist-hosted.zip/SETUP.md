# Crown.ologist app: hosted demo setup

This folder is your app on its own website. It works on any tablet or phone browser with
no Claude account, runs the full 7-Point AI analysis, and emails reports from your
Academy address with the photos attached.

**What's inside**
- `public/index.html`: the app
- `api/analyze.js`: sends photos to Claude with your AI key (kept on the server)
- `api/send-report.js`: emails reports to clients (through Resend)

Plan about an hour. Do it a few days before the show so you can test.

---

## Step 1: Get your AI key (Anthropic)
1. Go to **console.anthropic.com** and create an account for Crown.ologist Academy.
2. Add a payment method under **Billing**. You pay per analysis.
3. Go to **API Keys**, then **Create Key**. Copy it and keep it private.

## Step 2: Set up email sending (Resend)
1. Go to **resend.com** and create an account.
2. Under **Domains**, add your Academy's website domain and follow the steps to add
   the records to your domain's settings. This lets you send from your own address.
3. Under **API Keys**, create a key and copy it.

> Without a verified domain, Resend only lets you send test emails to your own address.
> For the show, verify your domain so reports reach clients.

## Step 3: Put the app online (GitHub + Vercel, both free)
1. Create a free account at **github.com**. Make a new **private** repository called
   `crownologist-app`, then use **Add file > Upload files** to upload everything in this
   folder (keep the `public` and `api` folders as they are).
2. Create a free account at **vercel.com** and sign in with GitHub.
3. Click **Add New > Project**, choose `crownologist-app`, and click **Deploy**.

## Step 4: Add your private settings in Vercel
In your project, open **Settings > Environment Variables** and add:

| Name | Value |
|---|---|
| `ANTHROPIC_API_KEY` | your key from Step 1 |
| `APP_ACCESS_CODE` | a code you choose, like `crown2026`; the app asks for it once |
| `RESEND_API_KEY` | your key from Step 2 |
| `REPORT_FROM` | `Crown.ologist Academy <reports@yourdomain.com>` |
| `REPLY_TO` | optional: the email clients' replies should go to |

Then go to **Deployments**, open the latest one, and choose **Redeploy** so the settings take effect.

## Step 5: Set up the tablet
1. Open your Vercel web address (it ends in `.vercel.app`) in **Safari** or **Chrome**.
2. Tap Share, then **Add to Home Screen**, so it opens like an app.
3. Create your account, add a client with **your own email**, run a full 7-Point
   analysis, and tap **Send report**. Enter your access code when asked.
4. Check that the report email arrives with the photos attached.

## At the show
- Bring a phone hotspot in case the show Wi-Fi is slow.
- Turn off auto-lock on the tablet.
- Keep one finished analysis saved to show instantly.

## Good to know
- **Keep your keys private.** They live only in Vercel's settings, never in the app.
- **The access code** stops strangers who find the web address from using your AI and email.
  Change it in Vercel any time.
- **Accounts and clients are saved on each device** in this demo version. The App Store
  version moves them to your own database.
- **Live scope view** still isn't possible from a website. Use the phone camera or scope photos
  saved to Photos.
- To change the AI model, add `ANTHROPIC_MODEL` in Vercel. The default is `claude-sonnet-5-5`.
  Current model names are listed at docs.claude.com.
